﻿using Con_ColAeroSpace_CSharpIntro;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

    internal class Program
    {
        static void Main(string[] args)
        {


        Con_ColAeroSpace_CSharpIntro.oopsdemo.ClsB obj = new Con_ColAeroSpace_CSharpIntro.oopsdemo.ClsB();

        
        
        Console.WriteLine("Hello World!!!");

            Console.ReadKey();  

        }



   public  class GlobalSetting
    {
        public static string Name { get; set; } = "some value";
    }

    }

